
	public abstract class Client // abstract class client 
	{
		abstract void readData(); // declaring abstract method readData
		abstract void processData(); // declaring abstract method processData
		abstract void printData(); // declaring abstract method printData


    } // end of abstract class client
