import java.io.*; // importing java.io package which consist of Classes like FileReader,BufferedReader for performing input & output functions like reading from file and writing into file 
import java.text.SimpleDateFormat; //importing SimpleDateFormat class from Text package to display time and date or timestamp
import java.util.*; // importing all the utility 

public class Records extends BankRecord //creating class Records that extends BankRecord
{
private void averagecomparator() throws IOException //declaring method AverageComparator which calculates the average income corresponding to specific region. 
{
	Arrays.sort(robj, new averagecomparator());
	
	//declaraing Variables
	
	double suminnercity = 0;
	double sumtown = 0;
	int countinnercity = 0;
	int counttown = 0;
	double sumrural = 0;
	int countrural = 0;
	double sumsuburban = 0;
	int countsuburban = 0;
	double line1 = 0;
	String line2 = null;
	double line3 = 0;
	String line4 = null;
	double line5 = 0;
	String line6 = null;
	double line7 = 0;
	String line8 = null;
	
	

for(int i = 0; i < robj.length ; ++i)  //for loop for iterating through Innercity region
	if (robj[i].getRegion().equals ("INNER_CITY"))
	{
		suminnercity += robj[i].getIncome(); // summation of income for innercity region 
		countinnercity++;  // counting no of incomes for innercity region
	
	}
        line3 = suminnercity/countinnercity; //calculating average of income for innercity region
        line4 = Double.toString(line3);
        System.out.println("Data Analytics Results:");
        System.out.printf("\nInnercity Region average income is: $%7.2f",line3);

for(int i = 0; i < robj.length ; ++i) //for loop for iterating through Rural region
	if (robj[i].getRegion().equals ("RURAL")) 
	{
		sumrural += robj[i].getIncome(); // summation of income for Rural region 
		countrural++;  // counting no of incomes for Rural region
	
	}
        line5 = sumrural/countrural; //calculating average of income for Rural region
        line6 = Double.toString(line5);
        System.out.printf("\nRural Region average income is: $%7.2f",line5);

for(int i = 0; i < robj.length ; ++i) //for loop for iterating through Suburban region
	if (robj[i].getRegion().equals ("SUBURBAN"))
	{
		sumsuburban += robj[i].getIncome(); // summation of income for Suburban region 
		countsuburban++; // counting no of incomes for Suburban region
	
	}
        line7 = sumsuburban/countsuburban; //calculating average of income for Suburban region
        line8 = Double.toString(line7);
        System.out.printf("\nSuburban Region average income is: $%7.2f",line7);

for(int i = 0; i < robj.length ; ++i) //for loop for iterating through Town region
	if (robj[i].getRegion().equals ("TOWN"))
	{
		sumtown += robj[i].getIncome(); // summation of income for Town region 
		counttown++; // counting no of incomes for Town region
	
	}
        line1 = sumtown/counttown; //calculating average of income for Town region
        line2 = Double.toString(line1);
        System.out.printf("\nTown Region average income is: $%7.2f",line1);
        
        
        //writing into file
try //begin of try block
{
File OutputFile = new File("BankRecords.txt");
FileWriter fw = new FileWriter(OutputFile,true); //if parameter is set true then new data will be appended to the previous data in file
BufferedWriter out1 = new BufferedWriter(fw);



out1.write("\n\n");
out1.write("Data Analytics Results:");
out1.write("\n");
out1.write(String.format("\nInnercity Region average income is: $%7.2f",line3));
out1.write(String.format("\nRural Region average income is: $%7.2f",line5));
out1.write(String.format("\nSuburban Region average income is: $%7.2f",line7));
out1.write(String.format("\nTown Region average income is: $%7.2f",line1));
out1.close(); // closing a file after writing
} // end of try block

//implementing catch block
catch(FileNotFoundException e)
{
	System.out.println("File in which data is to be written not found! "+ e);
}
catch(IllegalArgumentException e) 
{
	System.out.println("the Argument passed is illegal" +e); 
}
catch(ClassCastException e) 
{
	System.out.println("cannot perfrom Type Casting of inappropriate data types" +e); 
}
catch(Exception e) 
{
	System.out.println("Some other Exception" +e); 
} // end of catch block
} // end of method

 
 private void maxminincomecomparator() throws IOException //declaring calculateMinMax method which calculates the Maximum and Minimum incomes as per different regions
 {
	 Arrays.sort(robj, new maxminincomecomparator());
	 //declaring variables
	 
        double maxinnercity = 0;
		String line1 = null;
		double maxrural = 0;
		String line3 = null;
		double maxsuburban = 0;
		String line5 = null;
		double maxtown = 0;
		String line7 = null;
		
        for (int i = 0; i < robj.length ;i++)  
        {
              if (robj[i].getRegion().equals("INNER_CITY")) // for loop for iterating through innercity region 
              {
                     if (robj[i].getIncome() > maxinnercity) //finding maximum income
                     {
                    	 maxinnercity = robj[i].getIncome();
                     }
              } 
              
              else if (robj[i].getRegion().equals("RURAL")) // // for loop for iterating through Rural region
              {
                     if (robj[i].getIncome() > maxrural) // finding maximum income
                     {
                    	 maxrural = robj[i].getIncome();
                     }
              } 
              else if (robj[i].getRegion().equals("SUBURBAN")) // for loop for iterating through suburban region
              {
                     if (robj[i].getIncome() > maxsuburban) //finding maximum income
                     {
                    	 maxsuburban = robj[i].getIncome();
                     }
              } 
              else if (robj[i].getRegion().equals("TOWN")) // for loop for iterating through Town Region
              {
                     if (robj[i].getIncome() > maxtown) //  finding maximum income
                     {
                    	 maxtown = robj[i].getIncome();
                     }
              }
        }
        System.out.println("\n\n");
        System.out.println("Innercity Region maximum income : $"+maxinnercity);             
        System.out.println("Rural Region maximum income : $"+maxrural);             
        System.out.println("Suburban Region maximum income : $"+maxsuburban);            
        System.out.println("Town Region maximum income : $"+maxtown);
             
        //converting from Double to String
        
        line1 = Double.toString(maxinnercity);
		line3 = Double.toString(maxrural);
		line5 = Double.toString(maxsuburban);
		line7 = Double.toString(maxtown);
		
	//declaring variables
		
       double mininnercity = maxinnercity; 
       String line2 = null;
       double minrural = maxrural;
       String line4 = null;
       double minsuburban = maxsuburban;
   	   String line6 = null;
       double mintown = maxtown;
       String line8 = null;
        
        for (int j = 0; j < robj.length; j++) 
        {
              if ( robj[j].getRegion().equals("INNER_CITY")) // for loop for iterating through innercity region
              {
                     if ( robj[j].getIncome() < mininnercity) //finding minimum income
                     {
                    	 mininnercity =  robj[j].getIncome();
                     }
              } 
              else if ( robj[j].getRegion().equals("RURAL")) // for loop for iterating through Rural region
              {
                     if ( robj[j].getIncome() < minrural) // finding minimum income
                     {
                    	 minrural =  robj[j].getIncome();
                     }
              } 
              else if ( robj[j].getRegion().equals("SUBURBAN")) // for loop for iterating through Suburban region 
              {
                     if ( robj[j].getIncome() < minsuburban)  // finding minimum income
                     {
                    	 minsuburban =  robj[j].getIncome();
                     }
              } 
              else if ( robj[j].getRegion().equals("TOWN")) // for loop for iterating through Town region
              {
                     if ( robj[j].getIncome() < mintown) // finding minimum income
                     {
                    	 mintown =  robj[j].getIncome();
                     }
              }
        }
        System.out.println("\n\n");
        System.out.println("Innercity Region minimum income : $"+mininnercity);
        System.out.println("Rural Region minimum income : $"+minrural);       
        System.out.println("Suburban Region minimum income : $"+minsuburban);            
        System.out.println("Town Region minimum income : $"+mintown);
       
        line2 = Double.toString(mininnercity);
		line4 = Double.toString(minrural);
		line6 = Double.toString(minsuburban);
		line8 = Double.toString(mintown);
		
		//begin of try block
try 
{  // writing into a file
File OutputFile = new File("BankRecords.txt");
FileWriter fw = new FileWriter(OutputFile,true); //if parameter is set true then new data will be appended to the previous data in file
BufferedWriter out2 = new BufferedWriter(fw);


out2.write("\n\n");
out2.write("\nInnercity Region maximum income is: $"+line1);
out2.write("\nRural Region maximum income is: $"+line3);
out2.write("\nSuburban Region maximum income is: $"+line5);
out2.write("\nTown Region maximum income is: $"+line7);
out2.write("\n\n");
out2.write("\nInnercity Region minimum income is: $"+line2);
out2.write("\nRural Region minimum income is: $"+line4);
out2.write("\nSuburban region minimum income is: $"+line6);
out2.write("\nTown Region minimum income is: $"+line8);
out2.close(); // closing a file after writing
} // end of try block
catch(FileNotFoundException e)
{
	System.out.println("File in which data is to be written not found! "+ e);
}
catch(IllegalArgumentException e) 
{
	System.out.println("the Argument passed is illegal" +e); 
}
catch(ClassCastException e) 
{
	System.out.println("cannot perfrom Type Casting of inappropriate data types" +e); 
}
catch(Exception e) 
{
	System.out.println("Some other Exception" +e); 
}
}// end of maxminincomecomparator method
 


public static void femalecountcomparator() throws IOException //declaring femalecomparators method which calculates the total no of females as per specific region
{
	Arrays.sort(robj, new femalecountcomparator());
	//declaring variables
	
	int femalecountinnercity = 0;
	String line1 = null;
	int femalecountrural = 0;
	String line2 = null;
	int femalecountsuburban = 0;
	String line3 = null;
	int femalecounttown = 0;
	String line4 = null;

	for (int i = 0; i < robj.length; i++) 
	{
		if (robj[i].getSex().equals("FEMALE")) // females only 
		{
			if (robj[i].getMortgage().equals("YES") && robj[i].getsave_act().equals("YES")) // having mortgage and savings account
			{
				if (robj[i].getRegion().equals("INNER_CITY")) // in innercity region only
				{
					femalecountinnercity++; //calculating no of females
				}

				else if (robj[i].getRegion().equals("RURAL")) //in Rural region only
				{
					femalecountrural++; //calculating no of females
				} else if (robj[i].getRegion().equals("SUBURBAN")) // in Suburban region only
				{
					femalecountsuburban++; //calculating no of females
				} else if (robj[i].getRegion().equals("TOWN")) // in Town region only
				{
					femalecounttown++; //calculating no of females
				}
			}
		}
	}
	System.out.println("\n\n");
	System.out.println("InnerCity Females count with both a mortgage and savings account is: "+femalecountinnercity);
	line1 = Integer.toString(femalecountinnercity);
	System.out.println("Rural Females count with both a mortgage and savings account is : "+femalecountrural);
	line2 = Integer.toString(femalecountrural);
	System.out.println("Suburban Females count with both a mortgage and savings account is: "+femalecountsuburban);
	line3 = Integer.toString(femalecountsuburban);
	System.out.println("Town Females count with both a mortgage and savings account is: "+femalecounttown);
	line4 = Integer.toString(femalecounttown);	
	
	//begin of try block
try 
{       // writing into a file
File OutputFile = new File("BankRecords.txt");
FileWriter fw = new FileWriter(OutputFile,true); //if parameter is set true then new data will be appended to the previous data in file
BufferedWriter out3 = new BufferedWriter(fw);

out3.write("\n\n");
out3.write("\nInnercity Females count with both a mortgage and savings account is: "+line1);
out3.write("\nRural Females count with both a mortgage and savings account is: "+line2);
out3.write("\nSuburban Females count with both a mortgage and savings account is: "+line3);
out3.write("\nTown Females count with both a mortgage and savings account is: "+line4);
out3.close(); // closing a file after writing
} // end of try block
catch(FileNotFoundException e)
{
	System.out.println("File in which data is to be written not found! "+ e);
}
catch(IllegalArgumentException e) 
{
	System.out.println("the Argument passed is illegal" +e); 
}
catch(ClassCastException e) 
{
	System.out.println("cannot perfrom Type Casting of inappropriate data types" +e); 
}
catch(Exception e) 
{
	System.out.println("Some other Exception" +e); 
}
} //end of femalecountcomparator method


public static void malecountcomparator() throws IOException //declaring malecomparators method which will count the total no of males having 1 child and a car as per specific region
{
	Arrays.sort(robj, new malecountcomparator());
	// declaring variables
	
	int malecountinnercity = 0;
	String line1 = null;
	int malecountrural = 0;
	String line2 = null;
	int malecountsuburban = 0;
	String line3 = null;
	int malecounttown = 0;
	String line4 = null;

	for (int i = 0; i < robj.length; i++) 
	{
		if (robj[i].getSex().equals("MALE")) //males only
		{
			if (robj[i].getCar().equals("YES") //having a car and 1 child
					&& robj[i].getChildren() == 1)
			{
				if (robj[i].getRegion().equals("INNER_CITY")) //in innercity region 
				{
					malecountinnercity++; //calculating no of males
				} else if (robj[i].getRegion().equals("RURAL")) // in rural region
				{
					malecountrural++; //calculating no of males
				} else if (robj[i].getRegion().equals("SUBURBAN")) // in suburban region
				{
					malecountsuburban++; //calculating no of males
				}

				else if (robj[i].getRegion().equals("TOWN")) // in town region
				{
					malecounttown++; //calculating no of males
				}
			}

		}
	}
	System.out.println("\n\n");
	System.out.println("Innercity Region Males count with both a car and 1 child is: "+malecountinnercity);
	line1 = Integer.toString(malecountinnercity);
	System.out.println("Rural Region Males count with with both a car and 1 child is: "+malecountrural);
	line2 = Integer.toString(malecountrural);
	System.out.println("Suburban Region Males count with with both a car and 1 child is: "+malecountsuburban);
	line3 = Integer.toString(malecountsuburban);
	System.out.println("Town Region Males count with with both a car and 1 child is: "+malecounttown);
	line4 = Integer.toString(malecounttown);
	
	//begin of try block
	
try 
{     // writing into a file
File OutputFile = new File("BankRecords.txt");
FileWriter fw = new FileWriter(OutputFile,true); //if parameter is set true then new data will be appended to the previous data in file
BufferedWriter out4 = new BufferedWriter(fw);

out4.write("\n\n");
out4.write("\nInnercity Region Males count with both a car and 1 child is: "+line1);
out4.write("\nRural Region Males count with both a car and 1 child is: "+line2);
out4.write("\nSuburban Region Males count with both a car and 1 child is: "+line3);
out4.write("\nTown Region Males count with both a car and 1 child is: "+line4);
out4.write("\n\n");

// documentation 
String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()); 
out4.write("DATED = "+timeStamp);
out4.write("\nProgrammed by Vighnesh Sanjay Sawant\n");

out4.close(); // closing a file after writing
} // end of try block
catch(FileNotFoundException e)
{
	System.out.println("File in which data is to be written not found! "+ e);
}
catch(IllegalArgumentException e) 
{
	System.out.println("the Argument passed is illegal" +e); 
}
catch(ClassCastException e) 
{
	System.out.println("cannot perfrom Type Casting of inappropriate data types" +e); 
}
catch(Exception e) 
{
	System.out.println("Some other Exception" +e); 
}
} // end of malecountcomparator method

public static void main(String[] args) throws IOException // calling main method
{
    // TODO Auto-generated method stub
   
	Records rec = new Records(); //creating new object of Records class
    List<BankRecord> robj = new ArrayList<BankRecord>();
    
    rec.readData(); //using reference "rec" to call readData method
    rec.averagecomparator(); //using reference "rec" to call AverageComparator method
    rec.maxminincomecomparator(); //using reference "rec" to call calculateMaxMinIncome  method
    rec.femalecountcomparator(); //using reference "rec" to call femaleComparators method
    rec.malecountcomparator(); //using reference "rec" to call maleComparators method
    
    String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()); //using SimpleDateFormat class to get the current instance of date and time and using a proper format to display it
	System.out.println("\nDATED = " + timeStamp + "\nProgrammed by Vighnesh Sanjay Sawant\n"); // displaying the current instance of data and time

} // end of main method 
} 
// end of class Records
