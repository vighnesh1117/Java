import java.util.*; // importing all the utility functions 

public class femalecountcomparator implements Comparator<BankRecord> // declaring class which implements comparator for calculating females count as per specific location
{

	@Override
	public int compare(BankRecord o1, BankRecord o2) // method to compare between two objects
	{
		int result = o1.getSex().compareTo(o2.getSex()); // comparing two sexes
		if (result != 0) 
		{
			return result;
		}
		return o1.getMortgage().compareTo(o2.getMortgage()); //comparing two mortgages

	}

}
