import static org.junit.Assert.*;

import org.junit.Test;

public class JunitTest {

	AccountHolder acc = new AccountHolder();

	@Test
	public void testBalance() 
	{
		assertTrue(acc.getBalance() >= 0.0);
	}

	
	@Test
	public void testInitialInterest() 
	{
		assertTrue(acc.getInitialInterest() >= 0.0);
	
	}
	@Test
	public void testupdatedinterest(){
		
		assertTrue(acc.getInitialInterest() >= 0 && acc.getInitialInterest() <= 100 );
		
	}


}
