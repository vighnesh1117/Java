import java.util.Scanner;                        // importing scanner class from utility package to take inputs from user
import java.text.SimpleDateFormat;               // importing text package and using SimpleDateFormat as a class member to add date and time
import java.util.Calendar;                       // importing calender class from utility package to use and record specific instance of time


public class AccountHolderTest {                 // A test class which will link or call all the methods from the AccountHolder class 

	public static void main(String[] args) {     // A main method
		// TODO Auto-generated method stub\
		
		{
			try                                  //start of try block
			{
		
		
		
				AccountHolder ach = new AccountHolder();    // creating new object and reference of that object of AccountHolder class 
				Scanner sc=new Scanner(System.in);          // scanner class for taking inputs from user
				double intbal;
				System.out.println("Enter the initial balance : $");
				intbal = sc.nextDouble();                   // taking the initial balance from the user
				double Total_Initial_Balance = ach.initialbalance(intbal); // // calling the initial balance method 
				System.out.println("Initial balance: $"+Total_Initial_Balance); // displaying the initial balance
								
	 {

		 
		                double Amount_Deposited;                     // declaring variable

		                System.out.println("Enter amount to be deposited :");
		                Amount_Deposited = sc.nextDouble();                 // taking the amount to be deposited into the balance as an input from the user
		                double Total_Balance = ach.deposit(Amount_Deposited);   // calling the deposit method 
		                System.out.println(String.valueOf("Final balance after depositing $"+Amount_Deposited +" is = $" +Total_Balance)); // displaying the final balance after depositing some amount



		            	double Amount_Withdrawn;                    // declaring variable
		                System.out.println("Enter amount to be withdrawn = ");
		                Amount_Withdrawn=sc.nextDouble();                  // taking the amount to be withdrawn from the balance as a input from the user 
		                double Amount_After_Withdraw = ach.withdrawal(Amount_Withdrawn); // calling the withdrawal method
		                if (Amount_After_Withdraw < 100.0)     // checking whether the balance after withdrawal is below $100 or not 
		                {
		                	System.out.println("Alert! Since you are low on balance(less than $100 after withdrawing) you are prevented from doing any withdrawals. Thankyou ");   // if the balance after withdrawal is below 100 then informing the user about low funds 
		                	System.exit(0);                      // if the user is low on funds then not permitting him to withdraw further
		                }
		                else if(Amount_After_Withdraw < 500.0)   // checking if the balance after withdraw is less than 500
		                {
		                	Amount_After_Withdraw = Amount_After_Withdraw - 50.0; // $50 will be deducted from the balance if the balance is less than $500
		                System.out.println("$50 fee is deducted and your current balance is = $"+Amount_After_Withdraw);  // informing the user about deducting $50 from its balance
		                };
		                
		                
		                
		                System.out.println(String.valueOf("Final balance after withdrawinng $" +Amount_Withdrawn +" is $" +Amount_After_Withdraw)); // displaying final balance after withdrawing some amount
		                

		            
		                System.out.println("To see monthly balance for one year at 4%");  // prompting the user that the system is about to show the monthly interest 
		                System.out.println("base = $" +Amount_After_Withdraw);
		          
		                ach.monthlyinterest(4.0);  // calling the monthly interest method to calculate interest for each month at 4%
		                double New_Interest_Rate = 5; // setting the new rate of interest as 5% after 12 months 
		                ach.modifymonthlyinterest(New_Interest_Rate); // calling the method and passing the new rate of interest
		                sc.close(); // close method of scanner class invoked to no longer take input from user
		                
	 }
			}                       // end of try block
	 // begin of multiple catch block
	catch(NumberFormatException e)  //to check whether the number is in the correct format or not
			{
		System.out.println("Wrong data");
		    }
	catch(ArithmeticException e)    // to check whether arithmetic operations are correct or not
			{
		System.out.println("invalid Operation");
			}
	catch(IllegalArgumentException | NullPointerException e) // multi-catch block and to check whether the argument is illegal or not and check for null value assign to reference of an object
			{
				System.out.println("incorrect input, balance must be non negative");
			}
	catch(Exception e)              // calling superclass of all exceptions to check for any other random errors 
			{
		System.out.println("some other error");
			}		
finally                             // the above catch blocks may or may not run but finally will always run
{
	System.out.println("Program Execution ended!");
}
		                
		                String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()); // using the SimpleDateFormat class and calender class to get the specified instance of time and to display it in yyyy/MM/dd HH:MM:SS by using format method
		                System.out.println("Cur dt=" + timeStamp + "\nProgrammed by Vighnesh Sanjay Sawant\n"); // displaying the person who programmed the code
		                System.exit(0);// used to exit the program.

                       
	 
	}
	}
	}


