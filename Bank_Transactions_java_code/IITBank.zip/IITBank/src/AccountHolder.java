import java.util.Scanner;                                          //importing scanner class from util package for tokenizing or taking inputs from user

public class AccountHolder {                                       // Name of the class
	

	
	private double annualInterestRate;                         //Declaration of instance variables
	int month;
	private double intbal;                                    
	Scanner sc = new Scanner(System.in);                       // Scanner class for taking inputs from user regarding deposit, withdrawal
	
	
	AccountHolder()                                            //declaration of a default constructor
	{
		if(intbal < 0.0) //condition given for checking whether the user has entered balance less than 0.0
			

			throw new IllegalArgumentException("balance must be non negative"); //throwing exception of an illegal argument
	}
		                              	
	double totbal;                                    //declaration of instance variable
	                                                           //declaration of instance methods begin
	public double initialbalance(double intbal)               //declaration of method named as initial balance taking initial balance as a parameter 
		{
		if(intbal < 0.0) //condition given for checking whether the user has entered balance less than 0.0
		

			throw new IllegalArgumentException("balance must be non negative"); //throwing exception of an illegal argument
		else
		{ 
			this.intbal = intbal;   // self reference by using this keyword
		}
		
		totbal = totbal + intbal;
		return totbal;
	}
	
	public double deposit(double bal)                          //declaration of a method named as deposit taking balance as a parameter to calculate the total balance after depositing some amount                                                                     
	   
	{
		
		totbal = totbal + bal;           // balance after depositing certain amount                        
		return totbal;
	}
	
	public double withdrawal(double intbal)                   //declaration of method named as withdrawal taking balance as a parameter to calculate the total balance after withdrawing some amount                                                                      
	
	{
		totbal = totbal - intbal;      // balance after withdrawing certain amount
		return totbal;
		
	}
	public void monthlyinterest(double annualInterest)         //declaration of method named as monthly interest taking annual interest as a parameter to calculate monthly interest on the total balance

	{
if(totbal > 500.0 ) {                                               
		for (int i = 1; i<= 12; i++) {                         // for loop which calculate monthly interest for 12 months of a year for total balance greater than $500
			double interest = totbal * 4/1200;                 // calculating interest according to 4% per annum
			totbal = totbal + interest;                        // adding the calculated interest to the total balance
			System.out.printf("Month %d is $%6.2f%n", i , totbal);    // displaying the annual interest over the period of 12 months in a columnar format upto 2 digits of precision
			month = i;
		}
}else {
	double totbal1 = totbal - 50.0;
	for (int i = 1; i<= 12; i++) {                         // for loop which calculate monthly interest for 12 months of a year for total balance less than $500
		double interest = totbal * 4/1200;                 // calculating interest according to 4% per annum
		totbal1 = totbal1 + interest;                        // adding the calculated interest to the total balance
		System.out.printf("Month %d is $%6.2f%n", i , totbal1);    // displaying the annual interest over the period of 12 months in a columnar format upto 2 digits of precision
		month = i;
	
	
}
}

		
		annualInterestRate = 5;                                  // setting annual interest rate at 5% 
				double interest = totbal * annualInterestRate/1200;             // after completing 12 months of a year,for the next year the annual interest rate goes at 5% 
				totbal = totbal + interest;                    // adding the calculated interest at 5% to the total balance
				System.out.printf("After 12 months as per the updated interest rate of 0.05, the amount is $ %6.2f %n", totbal);         // displaying the annual interest at 5%

		
		
		
	}
	public void modifymonthlyinterest(double New_Interest_Rate)      // declaration of a method to update the interest
	{
	 if (New_Interest_Rate < 0 || New_Interest_Rate > 100)                 
	System.out.println("specify interest rate between 0 and 100");
	 else
	 {	
		 annualInterestRate = New_Interest_Rate;
	 }
	
	}

	public String toString()                                    // The toString method of String class by using format function is used to display output in a stated format
	{
		return String.format("Account balance $%.2f",intbal);  // account balance will be displayed upto 2 digits of precision
		
	}
	
	
	public double getBalance()   
	{
		return intbal;

	}
	public double getInitialInterest() 
	{
		return annualInterestRate;
	}
}
	
