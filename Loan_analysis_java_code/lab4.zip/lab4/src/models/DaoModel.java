package models; // creating pacckage models
import java.sql.*;
import java.util.*;
import lab4test.BankRecord;

	

	public class DaoModel extends BankRecord //creating class DaoModel which extends BankRecord having methods as same as DDL or DML or DCL or TCL statements in the SQL  
	{
		Connector con = new Connector(); //instantiating class "Connector" having reference variable con which is used to establish connection with the server  
		private Statement s1 = null; // declaring and initializing reference variable "s" of interface "Statement" which is used to access to the database and also for passing static SQL statements at runtime  

		public void createTable() throws Exception // method to create new table in the database 
		{
			
			try {
				
				s1 = con.getConnection().createStatement(); //used to execute SQL queries in the database
				System.out.println("Table successfully created in the Database!\n");
				String sql ="DROP TABLE IF EXISTS vigh_sawa_tab"; //dropping previously created table from the database
				s1.executeUpdate(sql); //is used to execute specified query like create, drop, insert etc
				
				
				// SQL query to create a new table in the database is stored in the form of String in java
				sql = "CREATE TABLE vigh_sawa_tab" + "(pid INTEGER NOT NULL AUTO_INCREMENT, " + "id VARCHAR(7), "
						+ "income NUMERIC(8,2), " + "pep VARCHAR(3), " + "PRIMARY KEY ( pid ))";
				s1.executeUpdate(sql);
				
				s1.close(); //closing the database connection

			} 
			
			catch (SQLException e) {
				System.err.println(e.getMessage());
			}

		} //end of method

		
		public void insertData(BankRecord[] robj) throws Exception //method to insert tuples or data in the database from the bank-details.csv file
		{
			try {
				s1 = con.getConnection().createStatement();

				String sql = null;
				for (int i = 0; i < robj.length; i++) // for loop for getting the entire records or data from the bank-details.csv file 
				{
					
					// SQL query to insert the data from the bank-detail.csv file into the database
					// here only data of id, income and pep is inserted in the database
					
					sql = "INSERT INTO vigh_sawa_tab(id,income,pep) " + "VALUES('" + robj[i].getId() + "','"
							+ robj[i].getIncome() + "','" + robj[i].getPep() + "')";
					s1.executeUpdate(sql);
				}
				System.out.println("Inserted Bank Records into the table");
				s1.close();
			} 
			catch (SQLException e) 
			{
				System.out.println("the SQL exception occured is: "+e);
			}
			catch (Exception e) 
			{
				System.out.println("the other exception occured is: "+e);
			}
		} // end of method

		
		public ResultSet getResultSet() throws Exception // result set is a cursor in oracle and my sql to execute an SQL query to fill the results of the executed query.
		{
			ResultSet r = null;
			try {
				s1 = con.getConnection().createStatement();
				String sql = "select id, income, pep from vigh_sawa_tab order by pep desc"; // select query fired to display the desired data or tuples in the API from the database
				r = s1.executeQuery(sql); // it is specifically used to execute SELECT statement in SQL and it combines the operation of resultset and execute()method
			} 
			catch (SQLException e) 
			{
				System.out.println("the SQL exception occured is: "+e);
			}
			catch (Exception e) 
			{
				System.out.println("the other exception occured is: "+e);
			}
			
			return r; 

		} // end of method
	} //end of class

	


