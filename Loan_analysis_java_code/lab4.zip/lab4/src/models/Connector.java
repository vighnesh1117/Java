package models;
import java.sql.*; //importing java.sql.* to connect with the database and handle any database exceptions 
public class Connector { //declaring connector class to allow the connection of database
	public Connection getConnection() 
	{
		Connection con = null; // declaring and initializing connection object 
		// Identifying and Registering the database driver 
		// here my sql is database and jdbc is an API and Driver is the name of the driver
		try {
			Class.forName("com.mysql.jdbc.Driver"); //for name is a static method of class "Class" 

			String connectionURL = "jdbc:mysql://www.papademas.net/510labs?autoReconnect=true&useSSL=false"; //to establish SSL connection with server's identity verification.
			con  = DriverManager.getConnection(connectionURL,"db510","510"); //connection to the database by having desired URL to get connected to and credentials like username "db510" and password "510"
		}
		catch (SQLException e) 
		{
			System.out.println("the SQL exception occured is: "+e);
		} 
		catch (ClassNotFoundException e) 
		{

			System.out.println("sorry we could not find the class: "+e);		
		}
	catch(Exception e)
		{
		System.out.println("the other error is: "+e);
		}
		
		return con; //returns the connection object after establishing the connection with server
	} //end of method getconnection

	
} // end of connector class
	
	
	
	