package controller; //creating package controller
 
import java.io.*; //importing all the input/output functions
import java.text.SimpleDateFormat;
import java.util.*; //importing all the utility functions
 
import lab4test.BankRecord; //importing class BankRecord
import lab4test.Mapper;//importing class mapper
import models.DaoModel;//importing class DaoModel
import views.LoanView;//importing class LoanView

public class LoanController extends BankRecord implements java.io.Serializable //creating class loanController which extends BankRecord and implements serializable interface and handles the DaoModel class and LoanView class
{
       
       public static void LoanController() throws ClassNotFoundException
 //declaring variables
       {
              
              long startTime; // to store the start time before serialization
              long endTime; // to store the end time after serialization.
              
              
              BankRecord rec = new BankRecord();  // instantiating class BankRecord
              rec.readData(); // calling method
              
              Mapper mapper_map= new Mapper(); // mapper_map object is created
              Mapper newRec = new Mapper();// newRec object is created.
              
              mapper_map.al_dt = new Date();// for performing encapsulation
              
              mapper_map.hmap = new HashMap<String, BankRecord>(); // implementing hashmap  
              
              System.out.println("hashmap starts at"+(new Date().toString()));
              System.out.println("");
              
              for (int i = 0; i<robj.length; i++)
              
              {
                    //The hash map is created for bank records
                     mapper_map.hmap.put(robj[i].getId(), robj[i]);// mapping of id using key value pair
              
              }
              
              System.out.println("ending hashmap ends "+(new Date().toString()));
              System.out.println("");
              
              startTime = System.currentTimeMillis(); // startTime is stored before serialization in milliseconds.
              
              FileOutputStream op = null; //to write data into a file
              
              System.out.println("Serialization starts");
              System.out.println("Start Time of Serialization is: "+(new Date().toString()));
              
              try {
              
                    op = new FileOutputStream("bankrec.ser"); //Serialization file is created and data is writeen into that file
                    
                    try
                    
                    {
                           
                           ObjectOutputStream out = new ObjectOutputStream(op);
                           try {
                           out.writeObject(mapper_map); //File Hash map is written in the file serialization
                           }
                           catch(Exception e) 
                           {
                                  
                           }
                           op.close();//closing the file
                           out.close();//closing the file
                    
                    } 
                    // implementing catch block
                    catch (IOException e) 
                    
                    {
                           
                           System.out.println("hash map is not getting inserted into serialize file ");
                           e.printStackTrace();
                           
                    }
                    
              } 
              
                    catch (FileNotFoundException en)
              
                    {     
                    
                           System.out.println("cannot create File Bankrec.ser ");
              
                    }
              
                           System.out.println("Serialization done or achieved");
                           System.out.println("");
              
                           System.out.println(" time at which the thread sleep is " + new Date());
              try
              
              {
              
                    Thread.sleep(5000);// making the thread sleep for 5000 milliseconds
                    
              } 
              
              catch (InterruptedException e) 
 
              {
                    
                    System.out.println("There is a problem in the thread function");
              e.printStackTrace();
              
              }
              
              System.out.println("time at which the thread awakes is " + new Date());
              System.out.println("");
              
              System.out.println("Start of deserialization");
              
              try
 
              {
              
                 FileInputStream ip = new FileInputStream("bankrecords.ser"); //creating new file named bankrecords
           
                 ObjectInputStream inp = new ObjectInputStream(ip);
                           
                 newRec = (Mapper)inp.readObject();
                 inp.close();
                 ip.close();
               }
              
catch (FileNotFoundException e) 
              
              {
                    
                    System.out.println("cannot fing File Bankrecords.ser for reading");
                    e.printStackTrace();
              
              }
              catch(Exception e)
                          {
                   
                           }

              endTime = System.currentTimeMillis();
              
                           
              System.out.println("Deserialization completed! "+(new Date().toString()));
              System.out.println("");
              System.out.println("The difference of time between serialization and deserialization in milliseconds is "+(endTime-startTime));
              System.out.println("");
              
             
              DaoModel dm = new DaoModel(); // creating new object of class DaoModel
              
              try
              
              {
                    dm.createTable(); //calling method to create table in database
                    dm.insertData(robj);//calling method to insert tuples in database
                    dm.getResultSet();//calling method to display data
              
              new LoanView(); //instantiating new object of class LoanView
              
              }
       catch(Exception e)
              
              {
    	   
              }
              
       }
       
       public static void main(String args[]) throws ClassNotFoundException
       {
    	 //documentation
   		String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()); //using SimpleDateFormat class to get the current instance of date and time and using a proper format to display it
   		System.out.println("\nDATED = " + timeStamp + "\nProgrammed by Vighnesh Sanjay Sawant\n"); // displaying the current instance of data and time
              LoanController l = new LoanController(); // instantiating class LoanController
              l.LoanController();
       
       }
 
 
}//class ends here
