package views; // creating package views
import java.sql.*;
import java.util.*;

import javax.swing.*; // importing all the swing components which is an extention to AWT to generate GUI
import javax.swing.table.DefaultTableModel;

import models.DaoModel;


public class LoanView extends JFrame //creating a class loanview that extends class Jframe to show what the class DaoModel contains.
{
	private static final long serializationID = 17111994L; //initializing the serializationid is to keep track of versions of the class for serial and deserialization
	DaoModel daoModel = new DaoModel(); //creating an new object of class DaoModel

	
	public LoanView() 
	{
		Vector<Vector<Object>> data = new Vector<Vector<Object>>(); // implementing vector as vector methods are synchronized for thread safety
		Vector<String> column = new Vector<String>(); //creating vector object
		
		//implementing try block
		try 
		{
			//result set is a cursor in oracle
			ResultSet r = daoModel.getResultSet(); //creating object/reference of ResultSet and getting values from class DaoModel
			ResultSetMetaData resultSetMetaData = r.getMetaData(); //using the above reference of ResultSet and storing it in ResultSetMetaData
			int columns = resultSetMetaData.getColumnCount(); //initializing no of columns  
			String cols = "";
			
			for (int i = 1; i <= columns; i++) // loop for filling up Jframe by the columns 
			{
				cols = resultSetMetaData.getColumnName(i);
				column.add(cols); //actual addition of columns

			}
			while (r.next()) 
			{
				Vector<Object> row = new Vector<Object>(columns);
				for (int i = 1; i <= columns; i++) {
					row.addElement(r.getObject(i)); 
				}
				data.addElement(row);
			}
			r.close(); //closing the connection

			DefaultTableModel defaultTableModel = new DefaultTableModel(data, column);

			
			// code for designing the API
			
			JTable jTable = new JTable(defaultTableModel);
			JFrame jFrame = new JFrame("BANK LOAN INFORMATION"); // title of frame
			jFrame.setSize(700, 200); //window size of frame
			jFrame.add(new JScrollPane(jTable)); //addition of scroll bar
			jFrame.setDefaultCloseOperation(EXIT_ON_CLOSE); // closing the frame
			jFrame.pack();
			jFrame.setVisible(true); //making the frame/API visible to user
		} 
		 // end of try block
		
		// implmenting catch block
		catch (SQLException e) 
		{
			System.out.println("the SQL exception occured is: "+e);
		}
		catch (Exception e) 
		{
			System.out.println("the other exception occured is: "+e);
		}
	}  // end of method
} //end of class
