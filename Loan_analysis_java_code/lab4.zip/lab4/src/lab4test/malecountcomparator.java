package lab4test;
import java.util.*; // importing all the utility functions 

public class malecountcomparator implements Comparator<BankRecord> // declaring class which implements comparator for calculating male count having a car and 1 child as per specific region
{

	@Override
	public int compare(BankRecord o1, BankRecord o2) // method to compare two objects
	{
		int result1 = o1.getSex().compareTo(o2.getSex()); //compare two sexes
		if (result1 != 0) 
		{
			return result1;
		}
		return o1.getCar().compareTo(o2.getCar()); 
	}

}


