package lab4test; //creating package lab4test
import java.text.SimpleDateFormat; //importing SimpleDateFormat class from Text package to display time and date or timestamp
import java.io.*; // importing java.io package which consist of Classes like FileReader,BufferedReader for performing input & output functions like reading from file and writing into file 
import java.util.*; // importing all the utility functions 

 
public class BankRecord extends Client   // creating class BankRecord which extends an abstract class Client
{
public static ArrayList<BankRecord> bankRecordResult = new ArrayList<BankRecord>();
protected static BankRecord[] robj=new BankRecord[600];   
static List<List<String>> recArray = new ArrayList<List<String>>(); // creating List for faster iteration and quick access to any random data. it is an Ordered but not Sorted

//declaring variables

private String Id;    
private int Age;      
private String Sex;  
private String Region; 
private double Income; 
private String Married;  
private int Children;   
private String Car;  
private String Save_act;  
private String Current_act;  
private String Mortgage;  
private String Pep;


//declaring getters and setters for displaying data and setting values of the data 

public String getId() //displaying customer's unique id
{
    return Id;
}

public void setId(String Id) //setting customer's unique id 
{
    this.Id = Id;
}

public int getAge() //displaying customer's age
{
    return Age;
}

public void setAge(int Age) //setting customer's age
{
    this.Age = Age;
}

public String getSex() // displaying customer's gender
{
    return Sex;
}

public void setSex(String Sex) //setting customer's gender (YES or NO)  
{
    this.Sex = Sex;
}

public String getRegion() // displaying customer's region
{
    return Region;
}

public void setRegion(String Region) //setting customer's region 
{
    this.Region = Region;
}

public double getIncome() // displaying customer's income
{
    return Income;
}

public void setIncome(double Income) //setting customer's income
{
    this.Income = Income;
}

public String Married() // displaying customer's marital status (YES or NO)
{
    return Married;
}

public void setMarried(String Married) //setting customer's marital status (YES or NO)
{
    this.Married = Married;
}

public int getChildren() // displaying whether customer has children (0,1,2......)
{
    return Children;
}

public void setChildren(int Children)  //setting whether customer has children (0,1,2,3.....)
{
    this.Children = Children;
}

public String getCar() //displaying whether customer has car (YES or NO)
{
    return Car;
}

public void setCar(String Car) //setting whether customer has car (YES or NO)
{
    this.Car = Car;
}

public String getsave_act() // displaying whether customer has Savings account (YES or NO)
{
    return Save_act;
}

public void setSave_act(String Save_act) //setting whether customer has Savings Account (YES or NO)
{
    this.Save_act = Save_act;
}

public String getCurrent_act() // displaying whether customer has Current Account (YES or NO)
{
    return Current_act;
}

public void setCurrent_act(String Current_act) //setting whether customer has Current Account (YES or NO)
{
    this.Current_act = Current_act;
}

public String getMortgage() // displaying whether customer has some mortgage (YES or NO)
{
    return Mortgage;
}

public void setMortgage(String Mortgage) //setting whether customer has mortgage (YES or NO)
{
    this.Mortgage = Mortgage;
}

public String getPep() 
{
    return Pep;
}

public void setPep(String Pep) 
{
    this.Pep = Pep;
}
 

@Override
public void readData() {  // declaring readData method to read data from file 
	try {                     // implementing try block to search for Exceptions
           File inputFile = new File("bank-Detail.csv");   // File Class 
           FileReader fr = new FileReader(inputFile);      // FileReader class to read character streams of low level stream
           BufferedReader in = new BufferedReader(fr);     // BufferedReader Class to read high level Character stream
           
           String Line; //declaring Line variable of type String 
        

           while((Line = in.readLine())!= null) // While loop for putting each and every character from file into a string using readLine method until the file is empty
        	   recArray.add(Arrays.asList(Line.split(",")));   // transferring data from string to list and each data is separately identified by the token "," by using the split method from Array Class 
          
           in.close(); // closing the file
	}

//begin of multiple catch statements and multi-catch statements
	catch(FileNotFoundException e) // exception occurs if desired file which is taken as input is NOT FOUND
	{
 System.out.println("unable to locate the file" +e); 
	}
	catch(EOFException e)          // exception occurs if JVM reaches End of file while parsing or retrieving data from file 
	{
		System.out.println("End of file reached" +e); 
	}
	catch(NullPointerException e)  // exception occurs if object which does not have any reference is called
	{
		System.out.println(e);    
	}
	catch(ArrayStoreException | ArrayIndexOutOfBoundsException | NegativeArraySizeException | NumberFormatException | IllegalThreadStateException e) // exception occurs when array is flooded, size of array is negative, number not in proper format
	{
		System.out.println(e); 
	}
	catch(IllegalArgumentException e) // Exception occurs when an argument passed is Illegal
	{
	System.out.println("The Argument you passed is Illegal" +e);	
	}
	catch(IOException e) // exception occurs during performing any input/output operations
	{
		System.out.println("Input/Output Exception while reading from file or writing into file" +e); 
	}
	catch(Exception e) // Super class of all exceptions if any other exception occurs
	{
		System.out.println("Some other Exception" +e); 
	}
	finally //implementing finally block which will always run
	{
	//System.out.println("Reading the data from file finished, File closes! and now ready for processing");
	}

		processData(); // calling processData method to process data from List

	} // end of readData method


@Override
protected

    // start of processData method
void processData() {
    // TODO Auto-generated method stub
	try { //try block to search for exceptions
    int i=0; // initializing variable for indexing an array 
    for(List<String> records: recArray) // declaring for each loop to process each data from List 
    {
    	// initialize array of objects
        robj[i]= new BankRecord();
        BankRecord bank = new BankRecord();
        
     // calling setters and populate them, data by data
        
        robj[i].setId(records.get(0));
        robj[i].setAge(Integer.parseInt(records.get(1)));
        robj[i].setSex(records.get(2));
        robj[i].setRegion(records.get(3));
        robj[i].setIncome(Double.parseDouble(records.get(4)));
        robj[i].setMarried(records.get(5));
        robj[i].setChildren(Integer.parseInt(records.get(6)));
        robj[i].setCar(records.get(7));
        robj[i].setSave_act(records.get(8));
        robj[i].setCurrent_act(records.get(9));
        robj[i].setMortgage(records.get(10));
        robj[i].setPep(records.get(11));
 
bankRecordResult.add(bank);
 
        i++;// populating the BankRecord array
 
        //System.out.println(obj[idx].getId());
        }
 
    printData();// calling printData method to print each data 
}// end of try block
	//implementing catch block
			catch(NullPointerException e) 
			{
				System.out.println("The object created does not have any reference or the reference of the created object is pointing to null" +e); 
			}
			catch(ClassCastException e) // exception occurs if type casting is done of inappropriate types
			{
				System.out.println("cannot perfrom Type Casting of inappropriate data types" +e); 
			}
			catch(ArrayIndexOutOfBoundsException | NegativeArraySizeException e) 
			{
				System.out.println("Array size not enough or Array size cannot be negative  " +e); 
			}
			catch(IllegalArgumentException e) 
			{
				System.out.println("The argument you passed is Illegal" +e); 
			}
			catch(Exception e) 
			{
				System.out.println("Some other Exception" +e); 
			}

} //end of processData method
 

@Override

public void printData() //declaring printData method to print data from array
{
try {		// begin of try block
	        // declaring variables to print the heading 
	//System.out.println("Displaying First 25 records from the entire bank-Details file");
	String a = "ID";
	String b = "AGE";
	String c = "SEX";
	String d = "REGION";
	String e = "INCOME";
	String f = "MARRIED";
	String g = "CHILDREN";
	String h = "CAR";
	String i = "SAVE_ACC";
	String j = "CURRENT_ACC";
	String k = "MORTGAGE";
	String l = "PEP";
//	System.out.printf("|%1$8s|\t|%2$4s|\t|%3$8s|\t|%4$12s|\t|%5$8s|\t|%6$8s|\t|%7$8s|\t|%8$5s|\t|%9$8s|\t|%10$12s|\t|%11$8s|\t|%12$4s|\n",a,b,c,d,e,f,g,h,i,j,k,l); // printing the header by using printf method from System Class 
	
	
		int j1 = 0;
		while( j1 < 25) // while loop for printing every data from array
		{
			
			// printing the actual values of header by using printf method from System class with respect to header above
		//	System.out.printf("|%1$8s|\t|%2$4s|\t|%3$8s|\t|%4$12s|\t|%5$8s|\t|%6$8s|\t|%7$8s|\t|%8$5s|\t|%9$8s|\t|%10$12s|\t|%11$8s|\t|%12$4s|\n",robj[j1].getId(),robj[j1].getAge(),robj[j1].getSex(),robj[j1].getRegion(),robj[j1].getIncome(),robj[j1].Married(),robj[j1].getChildren(),robj[j1].getCar(),robj[j1].getsave_act(),robj[j1].getCurrent_act(),robj[j1].getMortgage(),robj[j1].getPep());
			j1 = j1 + 1;
		}// end of try block
	} // end of printData method

//implementing catch block
catch(IllegalArgumentException e) 
{
	System.out.println("the Argument passed is illegal" +e); 
}
catch(ClassCastException e) 
{
	System.out.println("cannot perfrom Type Casting of inappropriate data types" +e); 
}
catch(ArrayIndexOutOfBoundsException | NegativeArraySizeException | ArrayStoreException e) 
{
	System.out.println(e); 
}
catch(Exception e) 
{
	System.out.println("Some other Exception" +e); 
}
finally 
{
//System.out.println("First 25 records printed");	
//System.out.println("\n\n");
//System.out.println("Data Analytics Results:");	
}
}//end of printData method
}


 



