package lab4test;
import java.util.*;
import java.util.HashMap;

public class Mapper implements java.io.Serializable

{

	public Date al_dt;
	public HashMap<String,BankRecord>hmap;
	
}
