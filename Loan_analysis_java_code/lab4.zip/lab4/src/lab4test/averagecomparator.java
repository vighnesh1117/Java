package lab4test;
import java.util.*; // importing all the utility functions 
public class averagecomparator implements Comparator<BankRecord> //declaring class which implements comparator for calculating average income as per specific location  
{
	public int compare(BankRecord o1, BankRecord o2) // method to compare between two objects
	{
		int result = o1.getRegion().compareTo(o2.getRegion()); // comparing two regions
	
	if (result != 0)
	{
		return result;
	}
return (int)(o1.getIncome()-o2.getIncome()); // returning ascending order of income
	}

}
