package application;

public class Login {
int medicalStoremanagerId = 0;
int adminId = 0;
String password = null;
public int getMedicalStoremanagerId() {
	return medicalStoremanagerId;
}
public void setMedicalStoremanagerId(int medicalStoremanagerId) {
	this.medicalStoremanagerId = medicalStoremanagerId;
}
public int getAdminId() {
	return adminId;
}
public void setAdminId(int adminId) {
	this.adminId = adminId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}
