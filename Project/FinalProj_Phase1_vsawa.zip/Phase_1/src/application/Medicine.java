package application;

public class Medicine extends Report implements MedicineOperations {
	int medicalStoremanagerId = 0;
	public int getMedicalStoremanagerId() {
		return medicalStoremanagerId;
	}
	public void setMedicalStoremanagerId(int medicalStoremanagerId) {
		this.medicalStoremanagerId = medicalStoremanagerId;
	}
	public String getM_BatchNumber() {
		return M_BatchNumber;
	}
	public void setM_BatchNumber(String m_BatchNumber) {
		M_BatchNumber = m_BatchNumber;
	}
	public String getM_MedicineName() {
		return M_MedicineName;
	}
	public void setM_MedicineName(String m_MedicineName) {
		M_MedicineName = m_MedicineName;
	}
	public String getM_Company() {
		return M_Company;
	}
	public void setM_Company(String m_Company) {
		M_Company = m_Company;
	}
	public int getM_Quantity() {
		return M_Quantity;
	}
	public void setM_Quantity(int m_Quantity) {
		M_Quantity = m_Quantity;
	}
	public String getM_ExpiryDate() {
		return M_ExpiryDate;
	}
	public void setM_ExpiryDate(String m_ExpiryDate) {
		M_ExpiryDate = m_ExpiryDate;
	}
	public String getM_PurchaseDate() {
		return M_PurchaseDate;
	}
	public void setM_PurchaseDate(String m_PurchaseDate) {
		M_PurchaseDate = m_PurchaseDate;
	}
	public String getM_Type() {
		return M_Type;
	}
	public void setM_Type(String m_Type) {
		M_Type = m_Type;
	}
	public double getM_SaleType() {
		return M_SaleType;
	}
	public void setM_SaleType(double m_SaleType) {
		M_SaleType = m_SaleType;
	}
	public double getM_PurchasePrice() {
		return M_PurchasePrice;
	}
	public void setM_PurchasePrice(double m_PurchasePrice) {
		M_PurchasePrice = m_PurchasePrice;
	}
	public int getM_RackNumber() {
		return M_RackNumber;
	}
	public void setM_RackNumber(int m_RackNumber) {
		M_RackNumber = m_RackNumber;
	}
	public int getM_SupplierId() {
		return M_SupplierId;
	}
	public void setM_SupplierId(int m_SupplierId) {
		M_SupplierId = m_SupplierId;
	}
	public String getM_SupplierName() {
		return M_SupplierName;
	}
	public void setM_SupplierName(String m_SupplierName) {
		M_SupplierName = m_SupplierName;
	}
	String M_BatchNumber=null;
    String M_MedicineName=null;
    String M_Company=null;
    int M_Quantity=0;
    String M_ExpiryDate=null;
    String M_PurchaseDate=null;
    String M_Type=null;
    double M_SaleType=0.0;
    double M_PurchasePrice=0.0;
    int M_RackNumber=0;
    int M_SupplierId=0;
    String M_SupplierName=null;
	@Override
	public String addNewMedicine() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void deleteMedicine(String M_BatchNo, String M_MedName) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String updateMedicine() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String searchMedicine(String M_BatchNo, String M_MedName) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String listMedicine() {
		// TODO Auto-generated method stub
		return null;
	}

}
