package application;

public interface SupplierOperations {
	public String addnewSupplier();
    public String searchSupplier();
    public String updateSupplier();
    public String deleteSupplier();
    public String listSupplier();


}
