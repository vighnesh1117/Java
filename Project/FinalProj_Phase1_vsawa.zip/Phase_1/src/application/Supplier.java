package application;

public class Supplier extends Report implements SupplierOperations {
	int medicalStoremanagerId = 0;
	public int getMedicalStoremanagerId() {
		return medicalStoremanagerId;
	}
	public void setMedicalStoremanagerId(int medicalStoremanagerId) {
		this.medicalStoremanagerId = medicalStoremanagerId;
	}
	public int getS_SupplierId() {
		return S_SupplierId;
	}
	public void setS_SupplierId(int s_SupplierId) {
		S_SupplierId = s_SupplierId;
	}
	public String getS_SupplierName() {
		return S_SupplierName;
	}
	public void setS_SupplierName(String s_SupplierName) {
		S_SupplierName = s_SupplierName;
	}
	public String getS_SupplierAddress() {
		return S_SupplierAddress;
	}
	public void setS_SupplierAddress(String s_SupplierAddress) {
		S_SupplierAddress = s_SupplierAddress;
	}
	public String getS_SupplierPhoneNumber() {
		return S_SupplierPhoneNumber;
	}
	public void setS_SupplierPhoneNumber(String s_SupplierPhoneNumber) {
		S_SupplierPhoneNumber = s_SupplierPhoneNumber;
	}
	public String getS_SupplierEmailId() {
		return S_SupplierEmailId;
	}
	public void setS_SupplierEmailId(String s_SupplierEmailId) {
		S_SupplierEmailId = s_SupplierEmailId;
	}
	int S_SupplierId=0;
    String S_SupplierName=null;
    String S_SupplierAddress=null;
    String S_SupplierPhoneNumber=null;
    String S_SupplierEmailId=null;
	@Override
	public String addnewSupplier() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String searchSupplier() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String updateSupplier() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String deleteSupplier() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String listSupplier() {
		// TODO Auto-generated method stub
		return null;
	}

}
