package application;

public class MedicineDetails extends Medicine {
int count = 0;
}
