package application;

public class DailyPurchaseReport extends Report{
String date = null;

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

}
