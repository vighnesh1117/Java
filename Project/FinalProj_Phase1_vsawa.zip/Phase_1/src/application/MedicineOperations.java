package application;

public interface MedicineOperations {
	public String addNewMedicine();
    public void deleteMedicine(String M_BatchNo,String M_MedName);
    public String updateMedicine();
    public String searchMedicine(String M_BatchNo, String M_MedName);
    public String listMedicine();

}
