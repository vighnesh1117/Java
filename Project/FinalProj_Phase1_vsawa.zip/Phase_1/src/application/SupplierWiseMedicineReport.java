package application;

public class SupplierWiseMedicineReport extends Report {
String S_SupplierName = null;

public String getS_SupplierName() {
	return S_SupplierName;
}

public void setS_SupplierName(String s_SupplierName) {
	S_SupplierName = s_SupplierName;
}

}
